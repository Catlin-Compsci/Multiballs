package networking;

public interface ConnectedThing {
    public int getId();
    public void setId(int id);
//    public MessageChunk getChunk();
//    public MessageChunk getCreate(int id);
}
