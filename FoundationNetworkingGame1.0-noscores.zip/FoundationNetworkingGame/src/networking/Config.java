package networking;

public class Config {
    public static boolean isClient = true;

    public static final String serverIp = "129.159.34.155";
//    public static final String serverIp = "10.255.0.160";
    public static final String localhost = "localhost";
    public static final int port = 8002;
}
