import client.Client;
import client.ConnectedClient;

public class Main {
    public static void main(String[] args) {
        new ConnectedClient();
    }
}
