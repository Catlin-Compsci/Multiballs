package engine;

public class Camera extends Thread {
    public double toGameX(double screenX) {
        return 0;
    }
    public double toGameY(double screenY) {
        return 0;
    }
}
